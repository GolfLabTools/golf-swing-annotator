# SwingLens — Golf Swing Annotation Tool

A web-based golf swing video annotation tool for analyzing and marking up swing footage. Upload a video, draw on top of it with various tools, and export the annotated result.

![Dark UI with green accents](https://img.shields.io/badge/UI-Dark%20%2B%20Green-00ff88?style=flat-square) ![No frameworks](https://img.shields.io/badge/Stack-Vanilla%20HTML%2FCSS%2FJS-orange?style=flat-square)

## Features

### Drawing Tools
- **Solid Line** — straight line overlay
- **Dashed Line** — dotted line for guides/angles
- **Arrow** — directional arrows with arrowheads
- **Circle** — click + drag ellipse (not locked to circle)
- **Rectangle** — click + drag rectangles
- **Freehand** — free-draw mode

### Color & Styling
- 5 preset colors (red, yellow, green, blue, white)
- Custom color picker for any color
- Adjustable stroke width (1–10px)
- Default color: red

### Video Controls
- Upload local video files (drag & drop or click)
- Play / Pause (spacebar or double-click)
- Scrubbable timeline with draggable playhead
- Frame-by-frame stepping (← → arrow keys)
- Playback speed: 0.25x → 2x in 0.25 increments

### Annotation Management
- Undo last stroke (Ctrl+Z)
- Clear all annotations
- Save/Load annotation sessions as JSON files

### Export
- Export annotated video as WebM using MediaRecorder API
- Composites video + canvas annotations into a single file
- Progress indicator during export

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `Space` | Play / Pause |
| `L` | Line tool |
| `D` | Dashed line tool |
| `A` | Arrow tool |
| `C` | Circle tool |
| `R` | Rectangle tool |
| `F` | Freehand tool |
| `Ctrl+Z` | Undo |
| `←` | Previous frame |
| `→` | Next frame |

## Running Locally

### Option 1: Direct file open
Simply open `index.html` in any modern browser (Chrome, Firefox, Edge).

### Option 2: Local server (recommended for video export)
```bash
# Python 3
python -m http.server 8000

# Node.js
npx serve .
```
Then open `http://localhost:8000`

## File Structure

```
golf-swing-annotator/
├── index.html    # Single-page app (HTML + CSS + JS)
└── README.md     # This file
```

## Technical Details

- **No frameworks** — pure HTML5, CSS3, and vanilla JavaScript
- **HTML5 Canvas** for drawing overlay
- **MediaRecorder API** for video export
- **Touch support** for basic mobile compatibility
- Responsive layout that adapts to screen size

## Browser Support

- Chrome 80+ (recommended)
- Firefox 75+
- Edge 80+
- Safari 14+ (limited MediaRecorder support)

## License

MIT
